package com.example.pokerai

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.BitmapShader
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.util.Base64
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.MotionEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        val d = resources.displayMetrics.density
        fun dp(i: Int) = (i * d).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(20), dp(48), dp(20), dp(24))
        }
        fun add(v: android.view.View, top: Int = 12) {
            root.addView(v, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) })
        }
        add(TextView(this).apply { text = "Poker AI"; textSize = 26f; setTypeface(typeface, Typeface.BOLD) }, 0)
        status = TextView(this).apply { textSize = 14f }
        add(status, 8)
        val key = EditText(this).apply {
            hint = "API key (Gemini / Groq / NVIDIA)"; setText(prefs.getString("akey", ""))
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        add(key, 20)
        val model = EditText(this).apply { hint = "Model"; setText((prefs.getString("amodel", "") ?: "").let { if (it.isEmpty() || it.startsWith("claude")) AiAgent.DEFAULT_MODEL else it }) }
        add(model, 10)
        val burl = EditText(this).apply { hint = "URL"; setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; setText(prefs.getString("aurl", "").let { if (it.isNullOrEmpty()) Config.BASE_URL else it }) }
        add(burl, 10)
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun preset(name: String, url: String, mdl: String) {
            presets.addView(Button(this).apply {
                text = name; setAllCaps(false)
                setOnClickListener { burl.setText(url); model.setText(mdl) }
            }, LinearLayout.LayoutParams(0, -2, 1f))
        }
        preset("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-3.8-flash")
        preset("Groq", "https://api.groq.com/openai/v1", "qwen/qwen3.8-27b")
        preset("NVIDIA", "https://integrate.api.nvidia.com/v1", "nvidia/nemotron-nano-12b-v2-vl")
        preset("Mistral", "https://api.mistral.ai/v1", "mistral-medium-3.5")
        add(presets, 6)
        add(Button(this).apply {
            text = "Save"
            setOnClickListener {
                prefs.edit().putString("akey", key.text.toString().trim())
                    .putString("aurl", burl.text.toString().trim())
                    .putString("amodel", model.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Saved", Toast.LENGTH_SHORT).show()
            }
        }, 14)
        add(Button(this).apply {
            text = "Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }, 10)
        add(TextView(this).apply {
            text = "1) (Only if Config.kt has no key) save the API key.  2) Turn on Poker AI in Accessibility: the menu opens by itself.  3) Tap the purple AI bubble, choose the tasks in the menu (big or small), press Start: the AI opens the game and does the rest. Tap the green bubble to stop."
            textSize = 13f
        }, 16)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        status.text = if (PokerService.inst != null) "Service: ON" else "Service: OFF (turn it on in Accessibility)"
    }
}

class PokerService : AccessibilityService() {
    companion object { var inst: PokerService? = null }
    private var ai: AiAgent? = null

    override fun onServiceConnected() { inst = this; ai = AiAgent(this).also { it.showBubble(); it.openMenu() } }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean {
        ai?.hideBubble(); ai = null; inst = null
        return super.onUnbind(i)
    }

    fun tapPx(x: Float, y: Float) {
        val path = Path().apply { moveTo(x, y) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 90)).build(), null, null)
    }

    fun swipePx(x1: Float, y1: Float, x2: Float, y2: Float) {
        val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
        dispatchGesture(GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350)).build(), null, null)
    }
}

class RateLimit(val ms: Long) : RuntimeException("rate limit")

class AiAgent(private val svc: PokerService) {
    private val h = Handler(Looper.getMainLooper())
    private val pool = Executors.newSingleThreadExecutor()
    private var running = false
    private var steps = 0
    private var bubble: TextView? = null
    private val history = ArrayDeque<String>()
    private var lastTap = ""
    private var sameTap = 0
    private var errCount = 0
    private var raiseHint = 0
    private var raiseSize = "1/2"
    private var pendingSig = ""
    private var hud: TextView? = null
    private var lastMs = 0L
    private var handsOnly = false
    private var sicbo = false
    private var sbPlaced = false
    private var sbLastTry = 0L
    private var sbRounds = 0
    private var sbStart = 0L
    private val rnd = java.util.Random()
    private var stable = 0
    private var needGone = false
    private var lastActAt = 0L
    private var readFails = 0
    private fun apiKey() = prefs.getString("akey", "")?.trim().orEmpty().ifEmpty { Config.KEY }
    fun openMenu() { if (menu == null) showMenu() }
    private fun live() = prefs.getBoolean("live", true)

    // Small status label (top center) so you can watch what the robot sees and does, live.
    private fun status(t: String, bg: Int = 0xAA000000.toInt()) {
        h.post {
            if (!running) return@post
            try {
                val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val d = svc.resources.displayMetrics.density
                if (hud == null) {
                    val tv = TextView(svc).apply {
                        textSize = 15f * (prefs.getInt("ui", 100) / 100f); setTextColor(Color.WHITE); alpha = 0.95f; setTypeface(typeface, Typeface.BOLD)
                        setPadding((8 * d).toInt(), (3 * d).toInt(), (8 * d).toInt(), (3 * d).toInt())
                        background = GradientDrawable().apply { setColor(0xAA000000.toInt()); cornerRadius = 20 * d }
                    }
                    val lp = WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
                        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE, PixelFormat.TRANSLUCENT
                    ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = (2 * d).toInt() }
                    wm.addView(tv, lp); hud = tv
                }
                hud?.background = GradientDrawable().apply { setColor(bg); cornerRadius = 20 * d }
                hud?.text = (if (live()) "\u26A1 " else "") + t + (if (lastMs > 0) "  \u2022 " + lastMs + "ms" else "")
            } catch (e: Exception) {}
        }
    }

    private fun hudHide() {
        hud?.let { try { (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        hud = null
    }
    private var actedSig = ""
    private var actedTries = 0
    private var menu: LinearLayout? = null
    private var bubbleLp: WindowManager.LayoutParams? = null
    private val prefs get() = svc.getSharedPreferences("p", Context.MODE_PRIVATE)
    private val TASKS = listOf("tut" to "Tutorial", "miss" to "Missions & gifts", "hands" to "Win chips (expert poker)")
    private fun task(k: String) = prefs.getBoolean("t_" + k, true)

    companion object {
        const val MAX_STEPS = 400
        const val GAME = "com.boyaa.androidmarketar"
        const val DEFAULT_MODEL = Config.MODEL
        const val HAND_SYS_FULL = """You read a Texas Hold'em table screenshot from the Boyaa Poker app (Arabic UI, landscape). I am the player in the bottom-center seat. Look very carefully and answer with ONE JSON object only, no other text:
{"hole":["Ah","Kd"],"board":["7c","2s","Jh"],"pot":1200,"call":200,"chips":8000,"players":2}
hole = my 2 face-up cards at the bottom center. board = the community cards in the middle of the table (0, 3, 4 or 5 cards). Card format: rank A K Q J T 9 8 7 6 5 4 3 2 followed by suit c (clubs, black) d (diamonds, red) h (hearts, red) s (spades, black). pot = the total pot (the number next to the word قدور under the dealer, or the chip total in the middle). call = the amount written on the green button (كلمة N means call N); 0 if the green button says فحص (check). chips = my own chip stack shown under my avatar. players = how many OTHER players are still in this hand (they still show cards or a bet and are not marked تخلي/folded). Numbers are plain integers (expand K = thousand, M = million). Never guess a card: look at the rank and the suit symbol of each card."""
        const val HAND_SYS = """You read a Texas Hold'em table (Boyaa Poker, Arabic UI). The image is a COLLAGE of 4 crops of one screenshot, from top to bottom: (1) TOP crop: the pot and the community cards in the middle of the table. (2) MIDDLE-LEFT crop: MY seat at the bottom center, with my 2 face-up cards and my chip stack. (3) MIDDLE-RIGHT small crop: the green action button (it says فحص = check, or كلمة followed by the amount to call). (4) BOTTOM thumbnail: the whole table, used only to count the opponents. Answer with ONE JSON object only, no other text:
{"hole":["Ah","Kd"],"board":["7c","2s","Jh"],"pot":1200,"call":200,"chips":8000,"players":2}
hole = my 2 face-up cards (crop 2). board = the community cards in crop 1 (0, 3, 4 or 5 cards). Card format: rank A K Q J T 9 8 7 6 5 4 3 2 followed by suit c (clubs, black) d (diamonds, red) h (hearts, red) s (spades, black). Look at the suit symbol of every card. pot = the total pot in crop 1 (the number next to the word قدور, or the chip total above the board). call = the number on the green button (crop 3), 0 if it says فحص. chips = my stack number under my avatar (crop 2). players = the number of OTHER seats in the thumbnail that still show blue card backs (not folded). Numbers are plain integers (expand K = thousand, M = million)."""
        const val REFINE = """You see a zoomed crop of a phone game screenshot with a thin grey grid labelled 0..1000 on both axes (x along top/bottom, y along left/right). Find the target named by the user and return the exact CENTER of that button/object inside the crop. Answer ONE JSON object only: {"x":0-1000,"y":0-1000} or {"found":false} if the target is not visible in the crop."""
        const val SYSTEM = """You control an Android phone and play "Texas Poker" (Boyaa, Arabic UI, usually landscape). Each step you get ONE screenshot and must answer with ONE JSON action. The screenshot has a thin grey GRID drawn on it with labels every 100 units (0..1000 on both axes, x along the top and bottom, y along the left and right). Use the grid labels to read coordinates: find the target's center relative to the nearest grid lines and interpolate.  Be fast and precise: first identify the screen type below, then act.

A) GOOGLE / ANDROID SCREENS: tap Sign in with Google / Continue as ... / Allow / Accept / I agree / متابعة / موافق / السماح. On a consent page swipe up until Continue is enabled, then tap it. Tick "قرات ووافقت" if shown.

B) WELCOME DIALOG ("مبروك،نجحت التسجيل ... تعلم فورا" with gold button تعلم فورا and a small link إهمال): tap the gold تعلم فورا. Never tap إهمال (finishing the tutorial gives chips).

C) TUTORIAL (a blonde dealer at the top with a speech bubble, purple/green table):
 - Bubble has text but NO button (or says انقر الشاشة لاستمرار): tap the middle of the green table to continue.
 - Bubble contains a question with 3 gold answer buttons (for example ما هو شكل ورقك الآن؟): work out the REAL poker hand from my 2 hole cards plus the board (pair = زوج واحد, two pair, three of a kind, straight = مستقيم, flush, full house ...) and tap the matching Arabic option. Think logically for other questions too.
 - Bubble has a gold button تلقي (reward after a correct answer): tap it.
 - Action buttons at the bottom right (red تخلي fold, green فحص check / كلمة call, orange زيادة raise) with a yellow frame, arrow or pointing hand: tap exactly the highlighted one. If the tutorial shows the bet panel (راهن with a vertical slider and buttons كل في / 2/3 / 1/2): follow the hand or the text, for example tap كل في when the tutorial says so, then tap the orange confirm button at the bottom right. Tutorial chips are play money, so following the lesson exactly is allowed.
 - If one of my cards is highlighted or a green chip/ring pulses, tap that.
 - End dialog (تهانينا ... with gold العب فورا and link إعادة تعلم): tap the gold العب فورا. Never tap إعادة تعلم.

D) LOBBY (large woman in the middle, gold بدأ سريعا, purple ملعب hold em, MTT, Tarneeb on the right, icon bar at the top right: basket, gift box, clipboard-with-checkmark, friends, ranking, profile, more):
 - Open Missions with the clipboard-with-checkmark icon (right of the gift box). A red dot on it means something can be claimed.
 - The gift-box icon with a red dot: open it and tap free reward buttons (تلقي / استلام / Collect). Never buy anything.
 - If nothing is left to claim, answer done.

E) MISSION POPUP (title MISSION, tabs مهام المبتدئين / مهمة يومية / مهمة انجازات, close X at the top right):
 - In every tab tap each gold تلقي button. If several gold buttons are visible together, use the "taps" action to tap them all at once (max 4).
 - Grey تم = already claimed: ignore. Blue أكمل مهمة / اذهب = not finished: ignore.
 - If the list continues below, swipe up to see more rows. A red dot on a tab means that tab still has something to claim.
 - After a claim, coins fly across the screen: that is normal, continue with the next button.
 - When all three tabs have no gold تلقي left, tap X to close the popup.

F) REAL HANDS outside the tutorial: a built-in poker engine decides, you only READ the table. TURN CHECK (be strict): it is my turn ONLY if ALL of these are true: (1) I am the bottom-center seat and my 2 hole cards are face up; (2) a timer ring or glowing bar is running around MY avatar; (3) the big action buttons at the bottom right are bright and tappable (not greyed out) and the small auto-fold / auto-check tick boxes are NOT what is showing; (4) cards are not still being dealt or animating. If any is false set "my_turn":false, or just answer wait. When it is MY turn and the action buttons (red تخلي, green فحص/كلمة, orange زيادة) are clickable, answer with the "hand" action: read my 2 hole cards, the community cards (0 to 5), the pot, the amount I must call (0 if I can check), my chip stack, how many OTHER players are still in the hand, and the CENTER of the three buttons. Cards are like "Ah","Td","7c","2s" (rank A K Q J T 9..2 + suit c d h s); read them very carefully. Numbers are plain integers (expand K=thousand, M=million). If the cards or buttons are not clearly visible, or it is not my turn (other players thinking, انتظر جولة تالية), answer wait. After I pressed raise and the bet panel (slider, 1/2, 2/3, كل في) is open, tap the 1/2 button (never كل في) and then the orange confirm button.

G) POP-UPS, ads and news: close with the X or إغلاق / Close / OK.

HARD RULES: NEVER tap anything about shop, store, recharge, top-up, buy, purchase, deposit, payment, subscriptions, watching ads, invite/share, or any real-money item. Never type text. Tap the exact CENTER of the target. If the screen is loading or animating, or you cannot see the target clearly, answer wait. If my last tap did not change the screen, try a different spot or back instead of repeating it.

Answer with ONE JSON object only, no other text, keep "why" under 6 words and name the target button in Arabic or English (for example "gold تلقي button"):
{"action":"tap","x":0-1000,"y":0-1000,"why":"..."}  (x,y inside the image: 0,0 top-left, 1000,1000 bottom-right)
or {"action":"taps","points":[{"x":..,"y":..},{"x":..,"y":..}]} (only for several gold claim buttons on one screen)
or {"action":"hand","my_turn":true,"hole":["Ah","Kd"],"board":["7c","2s","Jh"],"pot":1200,"call":200,"chips":8000,"players":2,"buttons":{"fold":{"x":..,"y":..},"call":{"x":..,"y":..},"raise":{"x":..,"y":..}}} (only for a real hand when it is my turn)
or {"action":"swipe","x":..,"y":..,"x2":..,"y2":..} or {"action":"back"} or {"action":"wait"} or {"action":"done"}."""
    }

    private fun bubbleIcon(size: Int, inset: Int): Bitmap? {
        val id = svc.resources.getIdentifier("bubble", "drawable", svc.packageName)
        if (id == 0) return null
        val src = BitmapFactory.decodeResource(svc.resources, id) ?: return null
        val inner = size - 2 * inset
        val sq = Bitmap.createScaledBitmap(src, inner, inner, true)
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val p = Paint()
        p.isAntiAlias = true
        p.shader = BitmapShader(sq, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
        val cv = Canvas(out)
        cv.translate(inset.toFloat(), inset.toFloat())
        cv.drawCircle(inner / 2f, inner / 2f, inner / 2f, p)
        return out
    }

    fun showBubble() {
        if (bubble != null) return
        val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = svc.resources.displayMetrics.density
        val size = (52 * d).toInt()
        val tv = TextView(svc).apply {
            text = "AI"; textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.WHITE); setTypeface(typeface, Typeface.BOLD)
        }
        val lp = WindowManager.LayoutParams(size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 24; y = (200 * d).toInt() }
        bubbleLp = lp
        var dx = 0f; var dy = 0f; var ix = 0; var iy = 0; var moved = false; var downAt = 0L
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { dx = e.rawX; dy = e.rawY; ix = lp.x; iy = lp.y; moved = false; downAt = System.currentTimeMillis() }
                MotionEvent.ACTION_MOVE -> {
                    if (Math.abs(e.rawX - dx) > 12 || Math.abs(e.rawY - dy) > 12) moved = true
                    if (moved) { lp.x = ix + (e.rawX - dx).toInt(); lp.y = iy + (e.rawY - dy).toInt(); wm.updateViewLayout(tv, lp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) { if (running) stop() else if (System.currentTimeMillis() - downAt > 600) startHands() else toggleMenu() }
            }
            true
        }
        bubbleIcon(size, (4 * d).toInt())?.let { tv.text = ""; tv.foreground = BitmapDrawable(svc.resources, it) }
        wm.addView(tv, lp); bubble = tv; paint()
    }

    fun hideBubble() {
        stop(); hideMenu()
        bubble?.let { (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) }
        bubble = null
    }

    private fun buildSystem(): String {
        val on = TASKS.filter { task(it.first) }.map { it.second }
        return SYSTEM + "\n\nUSER-SELECTED TASKS: " + (if (on.isEmpty()) "none" else on.joinToString(", ")) + ".\n" +
            "Ignore the small round AI bubble and the small black status label at the top: they are overlays, not part of the game. Do ONLY the selected tasks. Tutorial (sections B and C) only if Tutorial is selected. Missions and gifts (sections D and E) only if Missions & gifts is selected. " +
            "Real hands (section F) only if Play hands is selected: then from the lobby " + modeText() + " and keep playing hands until the user stops you; never answer done while Play hands is selected. " +
            "A screen that belongs to a task that is NOT selected: ignore it, close it if it blocks you, and continue with the selected tasks. " +
            "When Win chips is selected, also tap any free chip/bonus/reward button that appears (تلقي, استلام, Collect) but never anything that costs money. When every selected task is finished, answer done."
    }

    private val MODES = listOf("quick" to "Quick start", "holdem" to "Hold'em rooms", "mtt" to "MTT tournaments")
    private fun mode() = prefs.getString("mode", "quick") ?: "quick"
    private fun modeText() = when (mode()) {
        "holdem" -> "tap the purple ملعب hold em button, choose the room with the LOWEST blinds and sit down"
        "mtt" -> "tap MTT, join a tournament that is FREE to enter (never pay an entry fee) and play it"
        else -> "tap the gold بدأ سريعا to sit at a table"
    }

    private fun hideMenu() {
        menu?.let { try { (svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) } catch (e: Exception) {} }
        menu = null
    }

    private fun toggleMenu() { if (menu != null) hideMenu() else showMenu() }

    private fun showMenu() {
        val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val d = svc.resources.displayMetrics.density
        fun dp(i: Int) = (i * d).toInt()
        val big = prefs.getBoolean("big", true)
        val sc = prefs.getInt("ui", 100) / 100f
        fun chip(t: String, color: Int, onClick: () -> Unit) = TextView(svc).apply {
            text = t; textSize = 14f * sc; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(dp((14 * sc).toInt()), dp((9 * sc).toInt()), dp((14 * sc).toInt()), dp((9 * sc).toInt()))
            background = GradientDrawable().apply { setColor(color); cornerRadius = dp(12).toFloat() }
            setOnClickListener { onClick() }
        }
        fun lp(top: Int = 6, w: Int = ViewGroup.LayoutParams.MATCH_PARENT) =
            LinearLayout.LayoutParams(w, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(top); leftMargin = dp(if (big) 0 else 4) }
        val box = LinearLayout(svc).apply {
            orientation = if (big) LinearLayout.VERTICAL else LinearLayout.HORIZONTAL
            setPadding(dp(10), dp(10), dp(10), dp(10))
            background = GradientDrawable().apply {
                setColor(0xF01E1B2E.toInt()); cornerRadius = dp(18).toFloat(); setStroke(dp(1), 0xAA6D28D9.toInt())
            }
            if (big) minimumWidth = dp((210 * sc).toInt())
        }
        val startChip = chip("\u25B6  Start", 0xFF1B8E3E.toInt()) { hideMenu(); start() }
        val sizeChip = chip(if (big) "\u2013 Small" else "\u2922", 0xFF4B5563.toInt()) {
            prefs.edit().putBoolean("big", !big).apply(); hideMenu(); showMenu()
        }
        val closeChip = chip("\u2715", 0xFF7F1D1D.toInt()) { hideMenu() }
        if (big) {
            box.addView(TextView(svc).apply {
                text = "Poker AI  \u2022  choose tasks"; textSize = 15f * sc; setTextColor(Color.WHITE)
                setTypeface(typeface, Typeface.BOLD)
            }, lp(0))
            val st0 = prefs.getLong("start_chips", 0L); val cur0 = prefs.getLong("cur_chips", 0L)
            if (st0 > 0 && cur0 > 0) box.addView(TextView(svc).apply {
                text = "Chips: " + st0 + " \u2192 " + cur0 + "  (" + (if (cur0 >= st0) "+" else "") + (cur0 - st0) + ")"
                textSize = 12f * sc; setTextColor(0xFFFBBF24.toInt())
            }, lp(4))
            for ((k, name) in TASKS) {
                val on = task(k)
                box.addView(chip((if (on) "\u2714  " else "\u25CB  ") + name, if (on) 0xFF6D28D9.toInt() else 0xFF374151.toInt()) {
                    prefs.edit().putBoolean("t_" + k, !on).apply(); hideMenu(); showMenu()
                }, lp(8))
            }
            val lv = live()
            box.addView(chip(if (lv) "\u26A1  Live: ON (fast)" else "\u26A1  Live: OFF", if (lv) 0xFFB45309.toInt() else 0xFF374151.toInt()) {
                prefs.edit().putBoolean("live", !lv).apply(); hideMenu(); showMenu()
            }, lp(8))
            val m = mode()
            box.addView(chip("\uD83C\uDFAE  Game: " + (MODES.firstOrNull { it.first == m }?.second ?: "Quick start") + "  \u25B8", 0xFF0F766E.toInt()) {
                val i = MODES.indexOfFirst { it.first == m }
                prefs.edit().putString("mode", MODES[(i + 1) % MODES.size].first).apply(); hideMenu(); showMenu()
            }, lp(8))
            val szRow = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            szRow.addView(chip("A\u2212  Small", 0xFF4B5563.toInt()) {
                prefs.edit().putInt("ui", (prefs.getInt("ui", 100) - 15).coerceAtLeast(60)).apply(); hideMenu(); showMenu()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
            szRow.addView(chip("A+  Big", 0xFF4B5563.toInt()) {
                prefs.edit().putInt("ui", (prefs.getInt("ui", 100) + 15).coerceAtMost(220)).apply(); hideMenu(); showMenu()
            }, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
            box.addView(szRow, lp(8))
            box.addView(chip("\uD83C\uDFB2  Big / Small (auto)", 0xFFB45309.toInt()) { hideMenu(); startSicbo() }, lp(8))
            val sbTaps = prefs.getInt("sb_taps", 2)
            box.addView(chip("Bet size: " + sbTaps + " x chip   (tap to change)", 0xFF4B5563.toInt()) {
                val nx = when (prefs.getInt("sb_taps", 2)) { 1 -> 2; 2 -> 4; 4 -> 8; else -> 1 }
                prefs.edit().putInt("sb_taps", nx).apply(); hideMenu(); showMenu()
            }, lp(6))
            box.addView(chip("\uD83C\uDCCF  Play at this table now", 0xFF15803D.toInt()) { hideMenu(); startHands() }, lp(12))
            box.addView(startChip, lp(8))
            val row = LinearLayout(svc).apply { orientation = LinearLayout.HORIZONTAL }
            row.addView(sizeChip, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(4) })
            row.addView(closeChip, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(4) })
            box.addView(row, lp(8))
        } else {
            box.addView(chip("\uD83C\uDCCF", 0xFF15803D.toInt()) { hideMenu(); startHands() }, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT))
            box.addView(startChip, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT))
            box.addView(sizeChip, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT))
            box.addView(closeChip, lp(0, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        val b = bubbleLp
        val screenW = svc.resources.displayMetrics.widthPixels
        val bs = (52 * d).toInt()
        val mx = if (b == null) 24 else if (b.x > screenW / 2) (b.x - dp(((if (big) 222 else 200) * sc).toInt())).coerceAtLeast(0) else b.x + bs + dp(8)
        val params = WindowManager.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = mx; y = b?.y ?: dp(200) }
        wm.addView(box, params); menu = box
    }

    private fun paint() {
        bubble?.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(if (running) 0xFF1B8E3E.toInt() else 0xFF6D28D9.toInt())
            setStroke(4, 0x66FFFFFF)
        }
    }

    private fun toast(t: String) = h.post { Toast.makeText(svc, t, Toast.LENGTH_LONG).show() }

    private fun start() {
        val key = apiKey()
        if (Build.VERSION.SDK_INT < 30) { toast("Android 11+ required"); return }
        if (key.isEmpty()) { toast("No API key: put it in Config.kt (once) or in the Poker AI app"); return }
        svc.packageManager.getLaunchIntentForPackage(GAME)?.let {
            svc.startActivity(it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
        prefs.edit().putLong("start_chips", 0L).putLong("cur_chips", 0L).apply()
        pendingSig = ""; actedSig = ""; actedTries = 0
        running = true; steps = 0; errCount = 0; history.clear(); lastTap = ""; sameTap = 0; paint()
        h.postDelayed({ step() }, 3000)
    }

    fun stop() { running = false; handsOnly = false; sicbo = false; h.removeCallbacksAndMessages(null); hudHide(); paint() }

    private fun step() {
        if (!running || Build.VERSION.SDK_INT < 30) return
        if (steps++ >= (if (task("hands")) 3000 else MAX_STEPS)) { toast("AI: max steps"); stop(); return }
        svc.takeScreenshot(Display.DEFAULT_DISPLAY, pool, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp == null) { h.post { stop() }; return }
                    status("reading screen")
                    val t0 = System.currentTimeMillis()
                    val reply = ask(encode(bmp, if (live()) 960 else 1280, true), buildSystem(), "Your last actions: ${if (history.isEmpty()) "none" else history.joinToString(" | ")}\nWhat is the next single action?" + (if (raiseHint-- > 0) "\nI just pressed raise: if the bet panel is open tap the " + raiseSize + " button, then the orange confirm button." else ""))
                    lastMs = System.currentTimeMillis() - t0
                    errCount = 0
                    val refined = refineIfTap(bmp, reply)
                    h.post { act(refined, bmp.width, bmp.height) }
                } catch (e: RateLimit) {
                    toast("Rate limit: waiting " + (e.ms / 1000) + "s")
                    h.postDelayed({ step() }, e.ms)
                } catch (e: Exception) {
                    errCount++
                    toast("AI error ($errCount/5): " + (e.message ?: e.javaClass.simpleName))
                    if (errCount >= 5) h.post { stop() } else h.postDelayed({ step() }, 3000)
                }
            }
            override fun onFailure(code: Int) {
                if (code == 3) { h.postDelayed({ step() }, 400); return }
                errCount++
                toast("Screenshot failed ($code) $errCount/5")
                if (errCount >= 5) h.post { stop() } else h.postDelayed({ step() }, 1000)
            }
        })
    }


    // ===== Fast table player: finds the action buttons by colour (no AI call) and asks the AI only to read the cards =====
    private class Btns(val fx: Float, val fy: Float, val cx: Float, val cy: Float, val rx: Float, val ry: Float, val hasRaise: Boolean)

    private fun findButtons(bmp: Bitmap): Btns? {
        val w = 480
        val hh = (bmp.height * w / bmp.width.toFloat()).toInt()
        val sc = Bitmap.createScaledBitmap(bmp, w, hh, true)
        val pix = IntArray(w * hh)
        sc.getPixels(pix, 0, w, 0, 0, w, hh)
        fun zone(kind: Int, x0: Float, x1: Float): FloatArray? {
            val xa = (x0 * w).toInt(); val xb = (x1 * w).toInt()
            val ya = (0.855f * hh).toInt(); val yb = (0.99f * hh).toInt()
            var cnt = 0
            var minX = Int.MAX_VALUE; var maxX = -1; var minY = Int.MAX_VALUE; var maxY = -1
            for (y in ya until yb) {
                for (x in xa until xb) {
                    val c = pix[y * w + x]
                    val r = (c shr 16) and 0xFF
                    val g = (c shr 8) and 0xFF
                    val b = c and 0xFF
                    val hit = when (kind) {
                        0 -> r > 130 && g < 75 && b < 115 && r - g > 90
                        1 -> g > 120 && r < 110 && b < 130 && g - r > 60 && g - b > 30
                        else -> r > 195 && g > 60 && g < 190 && b < 80 && r - g > 40
                    }
                    if (hit) {
                        cnt++
                        if (x < minX) minX = x
                        if (x > maxX) maxX = x
                        if (y < minY) minY = y
                        if (y > maxY) maxY = y
                    }
                }
            }
            val area = (xb - xa) * (yb - ya)
            if (cnt < area * 0.15f) return null
            return floatArrayOf(((minX + maxX) / 2f) / w, ((minY + maxY) / 2f) / hh)
        }
        val f = zone(0, 0.64f, 0.755f) ?: return null
        val c = zone(1, 0.755f, 0.87f) ?: return null
        val r = zone(2, 0.87f, 0.985f)
        return Btns(f[0], f[1], c[0], c[1], r?.get(0) ?: 0.925f, r?.get(1) ?: c[1], r != null)
    }

    // Finds the LAST JSON object that contains the given key (models sometimes think out loud first).
    private fun extractJson(reply: String, key: String): JSONObject? {
        val k = reply.lastIndexOf("\"" + key + "\"")
        if (k < 0) return null
        val st = reply.lastIndexOf('{', k)
        if (st < 0) return null
        var depth = 0
        for (i in st until reply.length) {
            val ch = reply[i]
            if (ch == '{') depth++
            else if (ch == '}') {
                depth--
                if (depth == 0) return try { JSONObject(reply.substring(st, i + 1)) } catch (e: Exception) { null }
            }
        }
        return null
    }

    private fun startHands() {
        if (Build.VERSION.SDK_INT < 30) { toast("Android 11+ required"); return }
        if (apiKey().isEmpty()) { toast("No API key: save it in the Poker AI app first"); return }
        hideMenu()
        pendingSig = ""; actedSig = ""; actedTries = 0
        running = true; handsOnly = true; steps = 0; errCount = 0
        stable = 0; needGone = false; readFails = 0; lastActAt = 0L
        history.clear(); paint()
        status("playing: waiting for my turn")
        h.postDelayed({ playStep() }, 300)
    }

    private fun playStep() {
        if (!running || !handsOnly || Build.VERSION.SDK_INT < 30) return
        svc.takeScreenshot(Display.DEFAULT_DISPLAY, pool, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp == null) { h.postDelayed({ playStep() }, 400); return }
                    handsTurn(bmp)
                } catch (e: RateLimit) {
                    toast("Rate limit: waiting " + (e.ms / 1000) + "s")
                    h.postDelayed({ playStep() }, e.ms)
                } catch (e: Exception) {
                    errCount++
                    toast("AI error ($errCount/8): " + (e.message ?: e.javaClass.simpleName))
                    if (errCount >= 8) h.post { stop() } else h.postDelayed({ playStep() }, 2500)
                }
            }
            override fun onFailure(code: Int) {
                h.postDelayed({ playStep() }, if (code == 3) 400L else 1000L)
            }
        })
    }

    private fun handsTurn(bmp: Bitmap) {
        val b = findButtons(bmp)
        if (b == null) {
            stable = 0; needGone = false; pendingSig = ""
            if (System.currentTimeMillis() - lastActAt > 2500L) status("LIVE \u2022 \u064A\u0646\u062A\u0638\u0631 \u062F\u0648\u0631\u0643  (waiting for my turn)", 0xAA1E3A8A.toInt())
            h.postDelayed({ playStep() }, 220)
            return
        }
        if (needGone && System.currentTimeMillis() - lastActAt < 3000) {
            h.postDelayed({ playStep() }, 250); return
        }
        needGone = false
        stable++
        if (stable < 2) { h.postDelayed({ playStep() }, 120); return }
        status("\u064A\u0642\u0631\u0623 \u0627\u0644\u0637\u0627\u0648\u0644\u0629...  (reading the table)", 0xAA7C3AED.toInt())
        val t0 = System.currentTimeMillis()
        val useFull = readFails >= 2
        val reply = if (useFull) ask(encode(bmp, 960, false), HAND_SYS_FULL, "Read the table now. JSON only.", 700)
                    else ask(collage(bmp), HAND_SYS, "Read the table now. JSON only.", 700)
        lastMs = System.currentTimeMillis() - t0
        errCount = 0
        val a: JSONObject? = extractJson(reply, "hole")
        if (a == null) {
            readFails++
            status("no cards in reply: " + reply.replace("\n", " ").take(80), 0xCC7F1D1D.toInt())
            h.postDelayed({ playStep() }, 1200); return
        }
        val arrH = a.optJSONArray("hole")
        val arrB = a.optJSONArray("board")
        val hole = ArrayList<Int>()
        val board = ArrayList<Int>()
        if (arrH != null) for (i in 0 until arrH.length()) PokerEngine.parse(arrH.optString(i))?.let { hole.add(it) }
        if (arrB != null) for (i in 0 until arrB.length()) PokerEngine.parse(arrB.optString(i))?.let { board.add(it) }
        val all = HashSet<Int>(); all.addAll(hole); all.addAll(board)
        val okBoard = board.size == 0 || (board.size in 3..5)
        if (hole.size != 2 || !okBoard || all.size != hole.size + board.size) {
            readFails++
            status("could not read the cards ($readFails): " + a.toString().take(70), 0xCC7F1D1D.toInt())
            h.postDelayed({ playStep() }, 900); return
        }
        readFails = 0
        fun num(k: String): Long {
            val o = a.opt(k)
            return when (o) {
                is Number -> o.toLong()
                is String -> o.filter { it.isDigit() }.toLongOrNull() ?: 0L
                else -> 0L
            }
        }
        val pot = num("pot"); val call = num("call"); val chips = num("chips")
        val players = a.optInt("players", 1).coerceIn(1, 8)
        if (chips > 0) {
            if (prefs.getLong("start_chips", 0L) <= 0L) prefs.edit().putLong("start_chips", chips).apply()
            prefs.edit().putLong("cur_chips", chips).apply()
        }
        val d = PokerEngine.decide(hole, board, pot, call, chips, players)
        var move = d.move
        if (move == PokerEngine.Move.FOLD && call <= 0L) move = PokerEngine.Move.CHECK
        if (move == PokerEngine.Move.RAISE && !b.hasRaise) move = PokerEngine.Move.CALL
        val wv = bmp.width.toFloat(); val hv = bmp.height.toFloat()
        val tx: Float; val ty: Float
        if (move == PokerEngine.Move.FOLD) { tx = b.fx; ty = b.fy }
        else if (move == PokerEngine.Move.RAISE) { tx = b.rx; ty = b.ry }
        else { tx = b.cx; ty = b.cy }
        marker(tx * wv, ty * hv)
        svc.tapPx(tx * wv, ty * hv)
        if (move == PokerEngine.Move.RAISE) {
            val rx = b.rx * wv; val ry = b.ry * hv
            h.postDelayed({ if (running) svc.tapPx(rx, ry) }, 550)
        }
        history.addLast("engine: " + d.note)
        while (history.size > 8) history.removeFirst()
        fun sym(c: Int): String {
            val rk = "23456789TJQKA"[c / 4]
            val st = "\u2663\u2666\u2665\u2660"[c % 4]
            return (if (rk == 'T') "10" else rk.toString()) + st
        }
        val label = when (move) {
            PokerEngine.Move.FOLD -> "\u062A\u062E\u0644\u064A \u2716  (Fold)"
            PokerEngine.Move.RAISE -> "\u0632\u064A\u0627\u062F\u0629 \u25B2  (Raise)"
            PokerEngine.Move.CALL -> "\u0643\u0644\u0645\u0629 " + call + " \u2714  (Call)"
            else -> "\u0641\u062D\u0635 \u2714  (Check)"
        }
        val bgc = if (move == PokerEngine.Move.FOLD) 0xCCB91C1C.toInt() else if (move == PokerEngine.Move.RAISE) 0xCCC2410C.toInt() else 0xCC15803D.toInt()
        val cardsTxt = sym(hole[0]) + " " + sym(hole[1]) + (if (board.isNotEmpty()) "  |  " + board.joinToString(" ") { sym(it) } else "")
        status(cardsTxt + "   \u2192   " + label + "   (" + (d.equity * 100).toInt() + "%)", bgc)
        needGone = true; lastActAt = System.currentTimeMillis(); stable = 0
        h.postDelayed({ playStep() }, if (move == PokerEngine.Move.RAISE) 1300L else 800L)
    }


    // ===== Big / Small (Sic Bo) auto mode: pure chance, one small bet per round, no AI needed to find the buttons =====
    private fun avgRgb(bmp: Bitmap, nx: Float, ny: Float): IntArray {
        val cx = (nx * bmp.width).toInt()
        val cy = (ny * bmp.height).toInt()
        var r = 0; var g = 0; var b = 0; var n = 0
        for (dy in -4..4 step 2) {
            for (dx in -4..4 step 2) {
                val x = (cx + dx).coerceIn(0, bmp.width - 1)
                val y = (cy + dy).coerceIn(0, bmp.height - 1)
                val c = bmp.getPixel(x, y)
                r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF; n++
            }
        }
        return intArrayOf(r / n, g / n, b / n)
    }

    private fun parseChips(t: String): Long {
        val m = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*([KkMm]?)").find(t) ?: return 0L
        val num = m.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return 0L
        val mul = when (m.groupValues[2].uppercase()) { "K" -> 1000.0; "M" -> 1000000.0; else -> 1.0 }
        return (num * mul).toLong()
    }

    private fun readChips(bmp: Bitmap): Long {
        return try {
            val fw = bmp.width.toFloat(); val fh = bmp.height.toFloat()
            val part = Bitmap.createBitmap(bmp, (0.10f * fw).toInt(), (0.85f * fh).toInt(), (0.26f * fw).toInt(), (0.12f * fh).toInt())
            val th = (part.height * 260 / part.width.toFloat()).toInt()
            val sc = Bitmap.createScaledBitmap(part, 260, th, true)
            val o = ByteArrayOutputStream()
            sc.compress(Bitmap.CompressFormat.JPEG, 85, o)
            val b64 = Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
            val t = ask(b64, "Reply with ONLY my chip number shown in the picture (K = thousand, M = million), nothing else.", "Number?", 20)
            parseChips(t)
        } catch (e: Exception) { 0L }
    }

    private fun startSicbo() {
        if (Build.VERSION.SDK_INT < 30) { toast("Android 11+ required"); return }
        hideMenu()
        running = true; handsOnly = false; sicbo = true
        sbPlaced = false; sbLastTry = 0L; sbRounds = 0; sbStart = 0L; errCount = 0
        history.clear(); paint()
        status("\uD83C\uDFB2 \u0643\u0628\u064A\u0631 / \u0635\u063A\u064A\u0631 \u2022 starting", 0xAA92400E.toInt())
        h.postDelayed({ sicStep() }, 300)
    }

    private fun sicStep() {
        if (!running || !sicbo || Build.VERSION.SDK_INT < 30) return
        svc.takeScreenshot(Display.DEFAULT_DISPLAY, pool, object : AccessibilityService.TakeScreenshotCallback {
            override fun onSuccess(r: AccessibilityService.ScreenshotResult) {
                try {
                    val hb = r.hardwareBuffer
                    val hw = Bitmap.wrapHardwareBuffer(hb, r.colorSpace)
                    val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                    hb.close()
                    if (bmp == null) { h.postDelayed({ sicStep() }, 500); return }
                    sicTurn(bmp)
                } catch (e: Exception) {
                    errCount++
                    if (errCount >= 8) { toast("Error: " + (e.message ?: e.javaClass.simpleName)); h.post { stop() } }
                    else h.postDelayed({ sicStep() }, 1500)
                }
            }
            override fun onFailure(code: Int) {
                h.postDelayed({ sicStep() }, if (code == 3) 400L else 1000L)
            }
        })
    }

    private fun sicTurn(bmp: Bitmap) {
        val rp = avgRgb(bmp, 0.675f, 0.896f)
        val cn = avgRgb(bmp, 0.795f, 0.896f)
        val isSic = rp[1] > rp[0] + 30 && cn[0] > cn[1] + 35
        if (!isSic) {
            status("\uD83C\uDFB2 \u0643\u0628\u064A\u0631 / \u0635\u063A\u064A\u0631 \u2022 open the Big/Small table", 0xAA1E3A8A.toInt())
            h.postDelayed({ sicStep() }, 600); return
        }
        errCount = 0
        val bright = cn[0] > 150 && cn[0] - cn[1] > 70
        if (bright) {
            sbPlaced = true
            h.postDelayed({ sicStep() }, 450); return
        }
        if (sbPlaced) {
            sbPlaced = false
            sbRounds++
            val maxR = prefs.getInt("sb_max", 30)
            if (sbRounds >= maxR) {
                toast("Big/Small: finished $sbRounds rounds")
                h.post { stop() }; return
            }
        }
        if (sbStart == 0L || (sbRounds > 0 && sbRounds % 6 == 0 && System.currentTimeMillis() - sbLastTry > 4000L)) {
            val chips = readChips(bmp)
            if (chips > 0) {
                if (sbStart == 0L) sbStart = chips
                prefs.edit().putLong("cur_chips", chips).apply()
                if (chips < sbStart * 0.6) {
                    status("\u26D4 stop-loss: chips $chips (started with $sbStart)", 0xCCB91C1C.toInt())
                    toast("Stop-loss reached: chips $chips")
                    h.post { stop() }; return
                }
            }
        }
        if (System.currentTimeMillis() - sbLastTry < 2400L) { h.postDelayed({ sicStep() }, 350); return }
        sbLastTry = System.currentTimeMillis()
        val big = rnd.nextBoolean()
        val n = prefs.getInt("sb_taps", 2).coerceIn(1, 8)
        val wv = bmp.width.toFloat(); val hv = bmp.height.toFloat()
        val chipX = 0.393f * wv; val chipY = 0.894f * hv
        val zx = (if (big) 0.8125f else 0.207f) * wv; val zy = 0.473f * hv
        marker(zx, zy)
        svc.tapPx(chipX, chipY)
        for (i in 1..n) {
            h.postDelayed({ if (running && sicbo) svc.tapPx(zx, zy) }, 300L + i * 260L)
        }
        val side = if (big) "\u0643\u0628\u064A\u0631 (Big)" else "\u0635\u063A\u064A\u0631 (Small)"
        status("\uD83C\uDFB2 \u0627\u0644\u062C\u0648\u0644\u0629 " + (sbRounds + 1) + "  \u2192  " + side + "  \u00D7" + n, if (big) 0xCCC2410C.toInt() else 0xCC15803D.toInt())
        h.postDelayed({ sicStep() }, 600L + n * 260L)
    }

    // Sends only the useful parts of the table (a few small crops) instead of the whole screen: far fewer image tokens.
    private fun collage(src: Bitmap): String {
        val fw = src.width.toFloat(); val fh = src.height.toFloat()
        fun crop(x0: Float, y0: Float, x1: Float, y1: Float, tw: Int): Bitmap {
            val cx = (x0 * fw).toInt(); val cy = (y0 * fh).toInt()
            val cw = ((x1 - x0) * fw).toInt(); val ch = ((y1 - y0) * fh).toInt()
            val part = Bitmap.createBitmap(src, cx, cy, cw, ch)
            val th = (ch * tw / cw.toFloat()).toInt()
            return Bitmap.createScaledBitmap(part, tw, th, true)
        }
        val a = crop(0.28f, 0.20f, 0.72f, 0.57f, 420)
        val b = crop(0.40f, 0.60f, 0.68f, 0.93f, 270)
        val c = crop(0.755f, 0.85f, 0.87f, 0.99f, 150)
        val t = Bitmap.createScaledBitmap(src, 260, (src.height * 260 / src.width.toFloat()).toInt(), true)
        val cwid = maxOf(a.width, b.width + c.width + 8, t.width)
        val midH = maxOf(b.height, c.height)
        val chei = a.height + 4 + midH + 4 + t.height
        val out = Bitmap.createBitmap(cwid, chei, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        cv.drawColor(Color.BLACK)
        var y = 0
        cv.drawBitmap(a, 0f, 0f, null)
        y += a.height + 4
        cv.drawBitmap(b, 0f, y.toFloat(), null)
        cv.drawBitmap(c, (b.width + 8).toFloat(), y.toFloat(), null)
        y += midH + 4
        cv.drawBitmap(t, 0f, y.toFloat(), null)
        val o = ByteArrayOutputStream()
        out.compress(Bitmap.CompressFormat.JPEG, 80, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun encode(src: Bitmap, width: Int, grid: Boolean): String {
        val hh = (src.height * width / src.width.toFloat()).toInt()
        val s = Bitmap.createScaledBitmap(src, width, hh, true).copy(Bitmap.Config.ARGB_8888, true)
        if (grid) drawGrid(s)
        val o = ByteArrayOutputStream()
        s.compress(Bitmap.CompressFormat.JPEG, if (width <= 960) 70 else 80, o)
        return Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP)
    }

    private fun drawGrid(b: Bitmap) {
        val c = Canvas(b)
        val line = Paint().apply { color = 0x66CCCCCC; strokeWidth = 1f }
        val txt = Paint().apply {
            color = Color.YELLOW; textSize = b.height / 38f; isAntiAlias = true
            setShadowLayer(3f, 0f, 0f, Color.BLACK)
        }
        for (i in 1..9) {
            val gx = b.width * i / 10f
            val gy = b.height * i / 10f
            c.drawLine(gx, 0f, gx, b.height.toFloat(), line)
            c.drawLine(0f, gy, b.width.toFloat(), gy, line)
            val lab = (i * 100).toString()
            c.drawText(lab, gx + 2f, txt.textSize, txt)
            c.drawText(lab, gx + 2f, b.height - 4f, txt)
            c.drawText(lab, 2f, gy - 2f, txt)
            c.drawText(lab, b.width - txt.measureText(lab) - 2f, gy - 2f, txt)
        }
    }

    // Local poker engine turns the table reading into a button tap.
    private fun fromHand(a: JSONObject): JSONObject {
        val wait = JSONObject().put("action", "wait")
        fun cards(k: String): List<Int> {
            val arr = a.optJSONArray(k) ?: return emptyList()
            return (0 until arr.length()).mapNotNull { PokerEngine.parse(arr.optString(it)) }
        }
        val hole = cards("hole"); val board = cards("board")
        if (!a.optBoolean("my_turn", false)) { pendingSig = ""; status("not my turn"); return wait }
        val bt = a.optJSONObject("buttons") ?: return wait
        if (hole.size != 2 || board.size > 5 || board.size == 1 || board.size == 2) return wait
        if ((hole + board).toSet().size != hole.size + board.size) return wait
        // Two identical readings in a row = the table is stable and it really is my turn.
        val sig = hole.sorted().toString() + board.sorted() + a.optLong("call", 0) + "/" + a.optLong("pot", 0)
        if (sig != pendingSig) { pendingSig = sig; return JSONObject().put("action", "recheck") }
        if (sig == actedSig) { if (++actedTries > 2) return wait } else { actedSig = sig; actedTries = 1 }
        val chips = a.optLong("chips", 0)
        if (chips > 0) {
            var st = prefs.getLong("start_chips", 0L)
            if (st <= 0L) { st = chips; prefs.edit().putLong("start_chips", st).apply() }
            prefs.edit().putLong("cur_chips", chips).apply()
        }
        val d = PokerEngine.decide(hole, board, a.optLong("pot", 0), a.optLong("call", 0), a.optLong("chips", 0), a.optInt("players", 1))
        val key = when (d.move) { PokerEngine.Move.FOLD -> "fold"; PokerEngine.Move.RAISE -> "raise"; else -> "call" }
        val label = when (key) { "fold" -> "red تخلي fold button"; "raise" -> "orange زيادة raise button"; else -> "green فحص/كلمة button" }
        val p = bt.optJSONObject(key) ?: return wait
        history.addLast("engine: " + d.note)
        status("my turn: " + d.note)
        raiseHint = if (d.move == PokerEngine.Move.RAISE) 4 else 0
        raiseSize = if (d.big) "2/3" else "1/2"
        return JSONObject().put("action", "tap").put("x", p.optDouble("x", -1.0)).put("y", p.optDouble("y", -1.0)).put("why", label)
    }

    // Second pass: zoom into the area the model picked and ask again for the exact center.
    private fun refineIfTap(bmp: Bitmap, reply: String): String {
        try {
            var a = JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
            val wasHand = a.optString("action") == "hand"
            if (wasHand) a = fromHand(a)
            if (a.optString("action") != "tap") return a.toString()
            val x = a.optDouble("x", -1.0); val y = a.optDouble("y", -1.0)
            if (x !in 0.0..1000.0 || y !in 0.0..1000.0) return a.toString()
            if (live()) return a.toString() // live mode: skip the zoom pass for speed
            val cw = (bmp.width * 0.22).toInt().coerceAtMost(bmp.width)
            val ch = (bmp.height * 0.34).toInt().coerceAtMost(bmp.height)
            val left = ((x / 1000.0 * bmp.width) - cw / 2).toInt().coerceIn(0, bmp.width - cw)
            val top = ((y / 1000.0 * bmp.height) - ch / 2).toInt().coerceIn(0, bmp.height - ch)
            val crop = Bitmap.createBitmap(bmp, left, top, cw, ch)
            val r = ask(encode(crop, 900, true), REFINE, "Target: " + a.optString("why", "the button"))
            val j = JSONObject(r.substring(r.indexOf('{'), r.lastIndexOf('}') + 1))
            if (j.has("found") && !j.optBoolean("found", true)) return a.toString()
            val rx = j.optDouble("x", -1.0); val ry = j.optDouble("y", -1.0)
            if (rx !in 0.0..1000.0 || ry !in 0.0..1000.0) return a.toString()
            val nx = (left + rx / 1000.0 * cw) / bmp.width * 1000.0
            val ny = (top + ry / 1000.0 * ch) / bmp.height * 1000.0
            a.put("x", nx); a.put("y", ny)
            return a.toString()
        } catch (e: Exception) { return reply }
    }

    private fun ask(b64: String, sys: String, userText: String, maxTok: Int = 400): String {
        val p = svc.getSharedPreferences("p", Context.MODE_PRIVATE)
        val key = apiKey()
        var model = p.getString("amodel", DEFAULT_MODEL)?.trim().orEmpty()
        if (model.isEmpty() || model.startsWith("claude")) model = DEFAULT_MODEL
        val baseUrl = p.getString("aurl", "")?.trim()?.trimEnd('/').orEmpty().ifEmpty { Config.BASE_URL.trimEnd('/') }
        if (baseUrl.isNotEmpty()) {
            val oaModel = p.getString("amodel", "")?.trim().orEmpty().ifEmpty { DEFAULT_MODEL }
            val content = JSONArray()
                .put(JSONObject().put("type", "text").put("text", userText + " Reply with JSON only."))
                .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
            val oaBody = JSONObject().put("model", oaModel).put("max_tokens", if (baseUrl.contains("groq.com", true)) minOf(maxTok, 220) else maxTok).put("temperature", 0.0)
                .put("messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", if (oaModel.contains("nemotron", true)) sys + "\n/no_think" else sys))
                    .put(JSONObject().put("role", "user").put("content", content)))
            if (baseUrl.contains("groq.com", true) && oaModel.startsWith("qwen", true)) oaBody.put("reasoning_effort", "none")
            if (baseUrl.contains("generativelanguage", true)) oaBody.put("reasoning_effort", "low")
            val oc = URL("$baseUrl/chat/completions").openConnection() as HttpURLConnection
            oc.requestMethod = "POST"; oc.connectTimeout = 8000; oc.readTimeout = 30000; oc.doOutput = true
            oc.setRequestProperty("content-type", "application/json")
            oc.setRequestProperty("Authorization", "Bearer $key")
            oc.outputStream.use { it.write(oaBody.toString().toByteArray()) }
            val ocode = oc.responseCode
            if (ocode == 429) {
                val ra = oc.getHeaderField("retry-after")?.toDoubleOrNull() ?: 4.0
                throw RateLimit((ra * 1000).toLong().coerceIn(1500L, 60000L) + 300L)
            }
            val otxt = ((if (ocode in 200..299) oc.inputStream else oc.errorStream)?.bufferedReader()?.readText()) ?: ""
            if (ocode !in 200..299) throw RuntimeException("HTTP $ocode [$oaModel] " + otxt.replace("\n", " ").take(400))
            val msg = JSONObject(otxt).getJSONArray("choices").getJSONObject(0).getJSONObject("message")
            var outTxt = if (msg.isNull("content")) "" else msg.optString("content", "")
            if (outTxt.isBlank()) outTxt = msg.optString("reasoning_content", "") + " " + msg.optString("reasoning", "")
            return outTxt
        }
        val parts = JSONArray()
            .put(JSONObject().put("inlineData", JSONObject().put("mimeType", "image/jpeg").put("data", b64)))
            .put(JSONObject().put("text", userText))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", JSONArray().put(JSONObject().put("role", "user").put("parts", parts)))
            .put("generationConfig", genConfig(model))
        val c = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent")
            .openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 20000; c.readTimeout = 60000; c.doOutput = true
        c.setRequestProperty("content-type", "application/json")
        c.setRequestProperty("x-goog-api-key", key)
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        if (code == 429) {
            val ra = c.getHeaderField("retry-after")?.toDoubleOrNull() ?: 4.0
            throw RateLimit((ra * 1000).toLong().coerceIn(1500L, 60000L) + 300L)
        }
        val txt = ((if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.readText()) ?: ""
        if (code !in 200..299) {
            val msg = try {
                val e = JSONObject(txt).getJSONObject("error")
                e.optString("status") + ": " + e.optString("message")
            } catch (x: Exception) { txt }
            throw RuntimeException("HTTP $code [$model] " + msg.replace("\n", " ").take(400))
        }
        return JSONObject(txt).getJSONArray("candidates").getJSONObject(0)
            .getJSONObject("content").getJSONArray("parts").getJSONObject(0).getString("text")
    }

    private fun genConfig(model: String): JSONObject {
        val g = JSONObject().put("maxOutputTokens", 2048).put("responseMimeType", "application/json")
        if (model.contains("gemini-3")) {
            g.put("thinkingConfig", JSONObject().put("thinkingLevel", "low"))
        } else {
            g.put("temperature", 0.0)
            if (model.contains("2.5") && model.contains("flash")) g.put("thinkingConfig", JSONObject().put("thinkingBudget", 0))
        }
        return g
    }

    // Red dot where the AI is about to tap, so you can SEE if it hits the right spot.
    private fun marker(px: Float, py: Float) {
        h.post {
            try {
                val wm = svc.getSystemService(Context.WINDOW_SERVICE) as WindowManager
                val r = (14 * svc.resources.displayMetrics.density).toInt()
                val v = View(svc).apply { background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(0xAAFF0000.toInt()) } }
                val lp = WindowManager.LayoutParams(r * 2, r * 2, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = (px - r).toInt(); y = (py - r).toInt() }
                wm.addView(v, lp)
                h.postDelayed({ try { wm.removeView(v) } catch (e: Exception) {} }, 400)
            } catch (e: Exception) {}
        }
    }

    private fun act(reply: String, w: Int, hh: Int) {
        if (!running) return
        val a = try {
            JSONObject(reply.substring(reply.indexOf('{'), reply.lastIndexOf('}') + 1))
        } catch (e: Exception) {
            history.addLast("unparsable"); h.postDelayed({ step() }, 500); return
        }
        when (a.optString("action")) {
            "tap" -> {
                val x = a.optDouble("x", -1.0)
                val y = a.optDouble("y", -1.0)
                if (x !in 0.0..1000.0 || y !in 0.0..1000.0) { h.postDelayed({ step() }, 500); return }
                val k = "${(x / 40).toInt()},${(y / 40).toInt()}"
                sameTap = if (k == lastTap) sameTap + 1 else 0
                lastTap = k
                if (sameTap >= 6) { toast("AI: stuck, stopped"); stop(); return }
                marker((x / 1000.0 * w).toFloat(), (y / 1000.0 * hh).toFloat())
                svc.tapPx((x / 1000.0 * w).toFloat(), (y / 1000.0 * hh).toFloat())
                history.addLast("tap(${x.toInt()},${y.toInt()}) " + a.optString("why").take(40))
                status("tap: " + a.optString("why").take(30))
                h.postDelayed({ step() }, if (live()) 600L else 900L)
            }
            "swipe" -> {
                val x = a.optDouble("x", 500.0)
                val y = a.optDouble("y", 700.0)
                val x2 = a.optDouble("x2", x)
                val y2 = a.optDouble("y2", 300.0)
                svc.swipePx((x / 1000.0 * w).toFloat(), (y / 1000.0 * hh).toFloat(),
                    (x2 / 1000.0 * w).toFloat(), (y2 / 1000.0 * hh).toFloat())
                history.addLast("swipe"); h.postDelayed({ step() }, 600)
            }
            "back" -> {
                svc.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK)
                history.addLast("back"); h.postDelayed({ step() }, 700)
            }
            "recheck" -> { status("confirming the table"); h.postDelayed({ step() }, if (live()) 200L else 350L) }
            "wait" -> { history.addLast("wait"); status("waiting for my turn"); h.postDelayed({ step() }, if (live()) 600L else 1200L) }
            "taps" -> {
                val pts = a.optJSONArray("points")
                if (pts == null || pts.length() == 0) { h.postDelayed({ step() }, 500); return }
                val n = minOf(pts.length(), 4)
                for (i in 0 until n) {
                    val o = pts.optJSONObject(i) ?: continue
                    val px = o.optDouble("x", -1.0)
                    val py = o.optDouble("y", -1.0)
                    if (px in 0.0..1000.0 && py in 0.0..1000.0) {
                        h.postDelayed({ if (running) svc.tapPx((px / 1000.0 * w).toFloat(), (py / 1000.0 * hh).toFloat()) }, i * 450L)
                    }
                }
                history.addLast("taps x$n")
                h.postDelayed({ step() }, n * 450L + 500)
            }
            "done" -> { toast("AI: done"); stop() }
            else -> h.postDelayed({ step() }, 500)
        }
        while (history.size > 8) history.removeFirst()
    }
}
