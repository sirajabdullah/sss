package com.example.pokerai

/**
 * Paste your key ONCE here, build the app, and you never have to type anything on the phone.
 * (Anything typed in the app's settings screen overrides these values.)
 * Keep the built APK private: a key inside an APK can be extracted.
 */
object Config {
    const val KEY = ""          // e.g. "AIza..."  (Gemini API key)
    const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai"
    const val MODEL = "gemini-3.8-flash"
}
