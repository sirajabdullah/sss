package com.example.pokerai

import kotlin.random.Random

/** Local Texas Hold'em brain: hand evaluator + Monte-Carlo equity + pot-odds decision. */
object PokerEngine {
    enum class Move { FOLD, CHECK, CALL, RAISE }
    data class Decision(val move: Move, val equity: Double, val note: String, val big: Boolean = false)

    private const val RANKS = "23456789TJQKA"
    private const val SUITS = "cdhs"

    /** "Ah", "10s", "Td" -> card id (rank*4+suit) or null. */
    fun parse(c: String): Int? {
        val t = c.trim().replace("10", "T")
        if (t.length < 2) return null
        val r = RANKS.indexOf(t[0].uppercaseChar())
        val s = SUITS.indexOf(t[1].lowercaseChar())
        return if (r < 0 || s < 0) null else r * 4 + s
    }

    private fun score5(cs: IntArray): Long {
        val cnt = IntArray(13)
        val s0 = cs[0] % 4
        var flush = true
        for (c in cs) { cnt[c / 4]++; if (c % 4 != s0) flush = false }
        val ranks = (12 downTo 0).filter { cnt[it] > 0 }
            .sortedWith(compareByDescending<Int> { cnt[it] }.thenByDescending { it })
        var high = -1
        if (ranks.size == 5) {
            val mx = ranks.maxOrNull()!!; val mn = ranks.minOrNull()!!
            if (mx - mn == 4) high = mx
            else if (cnt[12] > 0 && cnt[0] > 0 && cnt[1] > 0 && cnt[2] > 0 && cnt[3] > 0) high = 3 // wheel
        }
        val top = cnt[ranks[0]]
        val cat = when {
            high >= 0 && flush -> 8
            top == 4 -> 7
            top == 3 && cnt[ranks[1]] == 2 -> 6
            flush -> 5
            high >= 0 -> 4
            top == 3 -> 3
            top == 2 && cnt[ranks[1]] == 2 -> 2
            top == 2 -> 1
            else -> 0
        }
        var v = cat.toLong()
        val tb = if (high >= 0) listOf(high) else ranks
        for (i in 0 until 5) v = v * 16 + tb.getOrElse(i) { 0 }.toLong()
        return v
    }

    /** Best 5-card score from 5..7 cards. */
    fun best(cards: IntArray): Long {
        val n = cards.size
        var best = -1L
        val pick = IntArray(5)
        for (mask in 0 until (1 shl n)) {
            if (Integer.bitCount(mask) != 5) continue
            var k = 0
            for (i in 0 until n) if (mask and (1 shl i) != 0) pick[k++] = cards[i]
            val s = score5(pick)
            if (s > best) best = s
        }
        return best
    }

    /** Chen-formula starting hand strength, normalised 0..1 (AA = 1.0). */
    fun chen(a: Int, b: Int): Double {
        val r1 = maxOf(a / 4, b / 4); val r2 = minOf(a / 4, b / 4)
        fun pts(r: Int) = when (r) { 12 -> 10.0; 11 -> 8.0; 10 -> 7.0; 9 -> 6.0; else -> (r + 2) / 2.0 }
        var s = pts(r1)
        if (r1 == r2) s = maxOf(5.0, s * 2)
        else {
            if (a % 4 == b % 4) s += 2.0
            val gap = r1 - r2 - 1
            s += when { gap <= 0 -> 0.0; gap == 1 -> -1.0; gap == 2 -> -2.0; gap == 3 -> -4.0; else -> -5.0 }
            if (gap <= 1 && r1 < 10) s += 1.0
        }
        return ((s + 1.0) / 21.0).coerceIn(0.0, 1.0)
    }

    fun equity(hole: List<Int>, board: List<Int>, opponents: Int, sims: Int = 900, minStr: Double = 0.0): Double {
        val known = (hole + board).toSet()
        val deck = (0 until 52).filter { it !in known }.toIntArray()
        val opp = opponents.coerceIn(1, 8)
        val needBoard = 5 - board.size
        val need = needBoard + opp * 2
        val rnd = Random(System.nanoTime())
        var total = 0.0
        repeat(sims) {
            for (i in 0 until need) { // partial Fisher-Yates
                val j = i + rnd.nextInt(deck.size - i)
                val t = deck[i]; deck[i] = deck[j]; deck[j] = t
            }
            if (minStr > 0.0) { // opponents who bet usually hold better than random cards
                for (o in 0 until opp) {
                    val i0 = needBoard + o * 2
                    var tries = 0
                    while (tries++ < 12 && chen(deck[i0], deck[i0 + 1]) < minStr) {
                        val j = need + rnd.nextInt(deck.size - need)
                        val k = need + rnd.nextInt(deck.size - need)
                        var t = deck[i0]; deck[i0] = deck[j]; deck[j] = t
                        t = deck[i0 + 1]; deck[i0 + 1] = deck[k]; deck[k] = t
                    }
                }
            }
            val full = board + (0 until needBoard).map { deck[it] }
            val me = best((hole + full).toIntArray())
            var win = true; var ties = 0
            for (o in 0 until opp) {
                val a = deck[needBoard + o * 2]; val b = deck[needBoard + o * 2 + 1]
                val os = best((listOf(a, b) + full).toIntArray())
                if (os > me) { win = false; break }
                if (os == me) ties++
            }
            if (win) total += 1.0 / (ties + 1)
        }
        return total / sims
    }

    fun decide(hole: List<Int>, board: List<Int>, pot: Long, call: Long, chips: Long, opponents: Int): Decision {
        val opp = opponents.coerceIn(1, 8)
        val ratio = if (call > 0) call.toDouble() / pot.coerceAtLeast(1) else 0.0
        val minStr = if (call > 0) 0.20 + 0.35 * minOf(1.0, ratio * 1.2) else 0.0
        val eq = equity(hole, board, opp, if (opp <= 2) 900 else 500, minStr)
        val str = chen(hole[0], hole[1])
        val fair = 1.0 / (opp + 1)
        val raiseTh = minOf(0.85, fair + 0.25)
        val odds = if (call > 0) call.toDouble() / (pot + call).coerceAtLeast(1) else 0.0
        val pct = "eq ${(eq * 100).toInt()}%"
        val canRaise = chips > call * 2
        if (call <= 0) {
            return if (eq > raiseTh && canRaise) Decision(Move.RAISE, eq, "$pct value bet", eq > 0.80)
            else Decision(Move.CHECK, eq, "$pct check")
        }
        if (board.isEmpty() && str < 0.40 && (chips <= 0 || call.toDouble() / chips > 0.03))
            return Decision(Move.FOLD, eq, "$pct weak preflop fold")
        val bigCall = chips > 0 && call.toDouble() / chips > 0.4
        return when {
            eq > raiseTh + 0.08 && canRaise -> Decision(Move.RAISE, eq, "$pct raise", eq > 0.80)
            bigCall && eq < 0.55 -> Decision(Move.FOLD, eq, "$pct big bet fold")
            eq > odds + 0.04 -> Decision(Move.CALL, eq, "$pct call (odds ${(odds * 100).toInt()}%)")
            else -> Decision(Move.FOLD, eq, "$pct fold (odds ${(odds * 100).toInt()}%)")
        }
    }
}
